-- phpMyAdmin SQL Dump
-- version 4.7.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: 2018-07-21 16:43:06
-- 服务器版本： 5.5.56-log
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `snake`
--
DROP DATABASE IF EXISTS `snake`;
CREATE DATABASE IF NOT EXISTS `snake` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `snake`;

-- --------------------------------------------------------

--
-- 表的结构 `snake_articles`
--

CREATE TABLE `snake_articles` (
  `id` int(11) NOT NULL COMMENT '文章id',
  `title` varchar(155) NOT NULL COMMENT '文章标题',
  `description` varchar(255) NOT NULL COMMENT '文章描述',
  `keywords` varchar(155) NOT NULL COMMENT '文章关键字',
  `thumbnail` varchar(255) NOT NULL COMMENT '文章缩略图',
  `content` text NOT NULL COMMENT '文章内容',
  `add_time` datetime NOT NULL COMMENT '发布时间',
  `apid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `snake_articles`
--

INSERT INTO `snake_articles` (`id`, `title`, `description`, `keywords`, `thumbnail`, `content`, `add_time`, `apid`) VALUES
(2, '2文章标题', '文章描述', '1', '/Yw/public/upload/20180707/9693139cc79132175c5aa59d7c819a11.jpg', '<p style=\"box-sizing: border-box; outline: 0px; padding: 0px; margin-top: 0px; margin-bottom: 16px; color: rgb(79, 79, 79); line-height: 26px; text-align: justify; word-break: break-all; font-family: -apple-system, &quot;SF UI Text&quot;, Arial, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, &quot;WenQuanYi Micro Hei&quot;, sans-serif, SimHei, SimSun; white-space: normal; background-color: rgb(255, 255, 255);\"><span style=\"font-size: 12px;\"><span style=\"color: rgb(51, 51, 51); font-family: verdana, Arial, Helvetica, sans-serif;\">Ionic既是一个CSS框架也是一个Javascript UI库。许多组件需要Javascript才能产生神奇的效果，尽管通常组件不需要编码，通过框架扩展可以很容易地使用，</span><span style=\"color: rgb(51, 51, 51); font-family: verdana, Arial, Helvetica, sans-serif; box-sizing: border-box; outline: 0px; word-break: break-all;\">Ionic 是目前最有潜力的一款 HTML5 手机应用开发框架。通过 SASS 构建应用程序，它 提供了很多 UI 组件来帮助开发者开发强大的应用。 它使用 JavaScript MVVM 框架和 AngularJS 来增强应用。提供数据的双向绑定，使用它成为 Web 和移动开发者的共同选择</span></span></p><p><br/></p>', '2017-09-16 17:47:44', 1),
(3, '1斗鱼', '中国内地最具影响力的女生成长系列图书。最了解女生的作家饶雪漫对话最真实“问题女生”，撰写她们真实的故事，还原与她们对话的过程，并且记录下自己的感触，与读者深情分享那些成长中的疼痛与挣扎。同时，每个故事还辅以权威青少年心理咨询机构、心理研究专家的分析，充分借助饶雪漫每年一届的“我不是坏女生”夏令营的宝贵经验，致力于将该书打造成为父母最应该与孩子共同阅读的成长指南。不管你是“好”女生还是“坏”女生，都该看看这本书，它告诉你，不只你一个人在与世界进行无休止的战斗；建议你与朋友、父母分享这本书，当他们懂得了你的伤', '2', '/novels/public/upload/20180715/01e7d6b2d7560466f5ad3063da257092.jpg', '<p><span style=\"color: rgb(51, 51, 51); font-family: &quot;Classic Grotesque W01&quot;, &quot;Hiragino Sans GB&quot;, PingFang-SC-Light, &quot;Microsoft YaHei&quot;, &quot;WenQuanYi Micro Hei&quot;, Arial, SimSun, sans-serif; font-size: 14px; text-align: justify; background-color: rgb(248, 248, 248);\">中国内地最具影响力的女生成长系列图书。最了解女生的作家饶雪漫对话最真实“问题女生”，撰写她们真实的故事，还原与她们对话的过程，并且记录下自己的感触，与读者深情分享那些成长中的疼痛与挣扎。同时，每个故事还辅以权威青少年心理咨询机构、心理研究专家的分析，充分借助饶雪漫每年一届的“我不是坏女生”夏令营的宝贵经验，致力于将该书打造成为父母最应该与孩子共同阅读的成长指南。不管你是“好”女生还是“坏”女生，都该看看这本书，它告诉你，不只你一个人在与世界进行无休止的战斗；建议你与朋友、父母分享这本书，当他们懂得了你的伤</span><span style=\"color: rgb(51, 51, 51); font-family: &quot;Classic Grotesque W01&quot;, &quot;Hiragino Sans GB&quot;, PingFang-SC-Light, &quot;Microsoft YaHei&quot;, &quot;WenQuanYi Micro Hei&quot;, Arial, SimSun, sans-serif; font-size: 14px; text-align: justify; background-color: rgb(248, 248, 248);\">中国内地最具影响力的女生成长系列图书。最了解女生的作家饶雪漫对话最真实“问题女生”，撰写她们真实的故事，还原与她们对话的过程，并且记录下自己的感触，与读者深情分享那些成长中的疼痛与挣扎。同时，每个故事还辅以权威青少年心理咨询机构、心理研究专家的分析，充分借助饶雪漫每年一届的“我不是坏女生”夏令营的宝贵经验，致力于将该书打造成为父母最应该与孩子共同阅读的成长指南。不管你是“好”女生还是“坏”女生，都该看看这本书，它告诉你，不只你一个人在与世界进行无休止的战斗；建议你与朋友、父母分享这本书，当他们懂得了你的伤</span></p>', '2018-07-15 10:11:38', 1),
(5, '推荐', '速度', '3', '/novels/public/upload/20180715/c9ab435ab504dc09909acdb9274ce876.jpg', '<p>发送</p>', '2018-07-15 10:31:15', 1);

-- --------------------------------------------------------

--
-- 表的结构 `snake_books`
--

CREATE TABLE `snake_books` (
  `bid` int(11) NOT NULL,
  `bname` varchar(50) NOT NULL,
  `bicon` varchar(255) NOT NULL,
  `bauthor` varchar(50) NOT NULL,
  `bintroduction` varchar(255) NOT NULL,
  `bpid` int(11) NOT NULL COMMENT '分类id'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `snake_books`
--

INSERT INTO `snake_books` (`bid`, `bname`, `bicon`, `bauthor`, `bintroduction`, `bpid`) VALUES
(1, '哈利.波特与魔法石', '/novels/public/upload/20180715/16217f15553d3da0f5e8b5d2094605cd.jpg', 'J.K.罗琳', '哈利.波特是个很坚强的小哥哥', 8),
(2, '帝国巨星', '/novels/public/upload/20180714/ea0b4f79267adcb822fa1d862e8cc447.jpg', '楼下赫本', '当红巨星惨遭绑架撕票，于是有了他的第二次重生。\n　　这一世，他吸取教训，决定低调做人，远离江湖是非，拥抱平安喜乐。\n　　只是，他虽不在江湖，但江湖却处处有他的传说。\n　　当他一出江湖，这江湖，便成了他的。', 4),
(3, '青春', '/novels/public/upload/20180715/2929c6a6adf30d0eef3c1c0853a6dcd5.jpg', '韩庚', '我有一个朋友，毕业之前虽然也没有什么远大的理想，但积极健康，毕业以后去找工作，好不容易才找到，给别人加工东西，一个月赚一千五百块，时常加班，加班有时候有工资，有时候没有工资，合起来一个月能赚两千。他家在二十公里外，买了一个电瓶车，每天早出晚归，刚刚结婚，买不起房子，好在农村当时盖了三层楼，他们把一层和二层都租给了外地来打工的人，每间两百多，一共租出去六间，一个月可以补贴一千五，这些外来打工的人往往一个家庭三个人住一间，每个人的收入是八百多，靠步行和骑车，在附近的工厂里上班，附近的工厂是比加工业污染更大的化', 8);

-- --------------------------------------------------------

--
-- 表的结构 `snake_categories`
--

CREATE TABLE `snake_categories` (
  `cid` int(11) NOT NULL,
  `catenames` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `createtime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `snake_categories`
--

INSERT INTO `snake_categories` (`cid`, `catenames`, `createtime`) VALUES
(3, '武侠修真', '2018-07-11 13:17:26'),
(4, '玄幻魔法', '2018-07-07 17:21:57'),
(5, '都市言情', '2018-07-14 16:41:21'),
(6, '历史军事', '2018-07-14 16:41:31'),
(7, '网游竞技', '2018-07-14 16:41:41'),
(8, '科幻小说', '2018-07-14 16:41:51'),
(9, '恐怖灵异', '2018-07-14 16:41:59'),
(10, '其它小说', '2018-07-14 16:42:10'),
(11, '全本小说', '2018-07-14 16:42:21');

-- --------------------------------------------------------

--
-- 表的结构 `snake_feedback`
--

CREATE TABLE `snake_feedback` (
  `fid` int(11) NOT NULL,
  `feedtitle` varchar(50) NOT NULL,
  `feedcontent` varchar(255) NOT NULL,
  `feedtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `snake_feedback`
--

INSERT INTO `snake_feedback` (`fid`, `feedtitle`, `feedcontent`, `feedtime`) VALUES
(15, '界面超级棒', '内容也可以嘿嘿', '2018-07-21 02:48:17'),
(17, '发大是大非啊', '飒飒法发法撒旦', '2018-07-21 03:33:08'),
(19, '打法的', '撒大苏打', '2018-07-21 03:42:13');

-- --------------------------------------------------------

--
-- 表的结构 `snake_node`
--

CREATE TABLE `snake_node` (
  `id` int(11) NOT NULL,
  `node_name` varchar(155) NOT NULL DEFAULT '' COMMENT '节点名称',
  `control_name` varchar(155) NOT NULL DEFAULT '' COMMENT '控制器名',
  `action_name` varchar(155) NOT NULL COMMENT '方法名',
  `is_menu` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否是菜单项 1不是 2是',
  `type_id` int(11) NOT NULL COMMENT '父级节点id',
  `style` varchar(155) DEFAULT '' COMMENT '菜单样式'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- 转存表中的数据 `snake_node`
--

INSERT INTO `snake_node` (`id`, `node_name`, `control_name`, `action_name`, `is_menu`, `type_id`, `style`) VALUES
(1, '用户管理', '#', '#', 2, 0, 'fa fa-users'),
(2, '管理员管理', 'user', 'index', 2, 1, ''),
(3, '添加管理员', 'user', 'useradd', 1, 2, ''),
(4, '编辑管理员', 'user', 'useredit', 1, 2, ''),
(5, '删除管理员', 'user', 'userdel', 1, 2, ''),
(6, '角色管理', 'role', 'index', 2, 1, ''),
(7, '添加角色', 'role', 'roleadd', 1, 6, ''),
(8, '编辑角色', 'role', 'roleedit', 1, 6, ''),
(9, '删除角色', 'role', 'roledel', 1, 6, ''),
(10, '分配权限', 'role', 'giveaccess', 1, 6, ''),
(11, '系统管理', '#', '#', 2, 0, 'fa fa-desktop'),
(12, '数据备份/还原', 'data', 'index', 2, 11, ''),
(13, '备份数据', 'data', 'importdata', 1, 12, ''),
(14, '还原数据', 'data', 'backdata', 1, 12, ''),
(15, '节点管理', 'node', 'index', 2, 1, ''),
(16, '添加节点', 'node', 'nodeadd', 1, 15, ''),
(17, '编辑节点', 'node', 'nodeedit', 1, 15, ''),
(18, '删除节点', 'node', 'nodedel', 1, 15, ''),
(19, '文章管理', 'articles', 'index', 2, 0, 'fa fa-book'),
(20, '文章列表', 'articles', 'index', 2, 19, ''),
(21, '添加文章', 'articles', 'articleadd', 1, 19, ''),
(22, '编辑文章', 'articles', 'articleedit', 1, 19, ''),
(23, '删除文章', 'articles', 'articledel', 1, 19, ''),
(24, '上传图片', 'articles', 'uploadImg', 1, 19, ''),
(25, '导航管理', 'categories', 'index', 2, 0, 'fa fa-navicon'),
(26, '导航列表', 'categories', 'index', 2, 25, ''),
(27, '添加导航', 'categories', 'categoriesadd', 1, 25, ''),
(28, '编辑导航', 'categories', 'categoriesedit', 1, 25, ''),
(29, '删除导航', 'categories', 'categoriesdel', 1, 25, ''),
(30, '图书管理', '#', '#', 2, 0, 'fa fa-file-text'),
(31, '图书列表', 'books', 'index', 2, 30, ''),
(32, '添加图书', 'books', 'booksadd', 1, 30, ''),
(33, '编辑图书', 'books', 'booksedit', 1, 30, ''),
(34, '删除图书', 'books', 'booksdel', 1, 30, ''),
(35, '问题反馈管理', '#', '#', 2, 0, 'fa fa-users'),
(36, '列表', 'feedback', 'index', 2, 35, ''),
(37, '删除反馈', 'feedback', 'feedbackdel', 1, 35, '');

-- --------------------------------------------------------

--
-- 表的结构 `snake_role`
--

CREATE TABLE `snake_role` (
  `id` int(11) NOT NULL COMMENT 'id',
  `role_name` varchar(155) NOT NULL COMMENT '角色名称',
  `rule` varchar(255) DEFAULT '' COMMENT '权限节点数据'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- 转存表中的数据 `snake_role`
--

INSERT INTO `snake_role` (`id`, `role_name`, `rule`) VALUES
(1, '超级管理员', '*'),
(2, '系统维护员', '1,2,3,4,5,6,7,8,9,10,11,12,13,14,19,20,21,22,23,24,25,26,27,28,29');

-- --------------------------------------------------------

--
-- 表的结构 `snake_user`
--

CREATE TABLE `snake_user` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT '用户名',
  `password` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT '密码',
  `login_times` int(11) NOT NULL DEFAULT '0' COMMENT '登陆次数',
  `last_login_ip` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT '最后登录IP',
  `last_login_time` int(11) NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `real_name` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT '真实姓名',
  `status` int(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `role_id` int(11) NOT NULL DEFAULT '1' COMMENT '用户角色id'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- 转存表中的数据 `snake_user`
--

INSERT INTO `snake_user` (`id`, `user_name`, `password`, `login_times`, `last_login_ip`, `last_login_time`, `real_name`, `status`, `role_id`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 68, '106.114.251.171', 1532144406, 'admin', 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `snake_articles`
--
ALTER TABLE `snake_articles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `snake_books`
--
ALTER TABLE `snake_books`
  ADD PRIMARY KEY (`bid`);

--
-- Indexes for table `snake_categories`
--
ALTER TABLE `snake_categories`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `snake_feedback`
--
ALTER TABLE `snake_feedback`
  ADD PRIMARY KEY (`fid`);

--
-- Indexes for table `snake_node`
--
ALTER TABLE `snake_node`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `snake_role`
--
ALTER TABLE `snake_role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `snake_user`
--
ALTER TABLE `snake_user`
  ADD PRIMARY KEY (`id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `snake_articles`
--
ALTER TABLE `snake_articles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '文章id', AUTO_INCREMENT=6;
--
-- 使用表AUTO_INCREMENT `snake_books`
--
ALTER TABLE `snake_books`
  MODIFY `bid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- 使用表AUTO_INCREMENT `snake_categories`
--
ALTER TABLE `snake_categories`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- 使用表AUTO_INCREMENT `snake_feedback`
--
ALTER TABLE `snake_feedback`
  MODIFY `fid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- 使用表AUTO_INCREMENT `snake_node`
--
ALTER TABLE `snake_node`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
--
-- 使用表AUTO_INCREMENT `snake_role`
--
ALTER TABLE `snake_role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id', AUTO_INCREMENT=3;
--
-- 使用表AUTO_INCREMENT `snake_user`
--
ALTER TABLE `snake_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
